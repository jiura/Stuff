﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace PowerBIEmbed.Migrations
{
    public partial class MenuRoleNameCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "RoleName",
                table: "Menus",
                nullable: false,
                defaultValue: "");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "RoleName",
                table: "Menus");
        }
    }
}
