﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PowerBIEmbed.Models
{
    public class Menu
    {
        public int ID { get; set; }
        [Required]
        [Display(Name = "Ordenação")]
        public int Order { get; set; }
        [Required]
        [Display(Name = "Nome")]
        public string Name { get; set; }
        [Required]
        [Display(Name = "Workspace")]
        public Guid WorkspaceID { get; set; }
        [Required]
        [Display(Name = "Conjunto de Dados")]
        public Guid DatasetID { get; set; }
        [Required]
        [Display(Name = "Relatório")]
        public Guid ReportID { get; set; }
        [Required]
        [Display(Name = "Página")]
        public string ReportPageName { get; set; }
        [Required]
        [Display(Name = "Largura")]
        public int ReportWidth { get; set; }
        [Required]
        [Display(Name = "Altura")]
        public int ReportHeight { get; set; }
        [Required]
        [Display(Name = "Nome da Função")]
        public string RoleName { get; set; }

        [Required]
        [Display(Name = "Grupo de Menus")]
        public int MenuGroupID { get; set; }
        [Display(Name = "Grupo")]
        public virtual MenuGroup Group { get; set; }
        public virtual ICollection<MenuUser> MenuUsers { get; set; }
    }

    //Joining Table da relação Many to Many
    public class MenuUser
    {
        public int MenuID { get; set; }
        public Menu Menu { get; set; }
        public string UserID { get; set; }
        public ApplicationUser User { get; set; }
    }
}
