﻿using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Microsoft.PowerBI.Api.V2;
using Microsoft.Rest;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace PowerBIEmbed.Models
{
    public class PBIEmbeddedConfig
    {
        public string AuthorityUrl { get; set; }
        public string ResourceUrl { get; set; }
        public string ApiUrl { get; set; }
        public string EmbedUrlBase { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }
        public string ClientId { get; set; }
        public string ClientSecret { get; set; }

        public PowerBIClient Client;

        public async Task InitializeClient()
        {
            /*var oauthEndpoint = new Uri(AuthorityUrl);
            OAuthResult authenticationResult;
            using (var htppClient = new HttpClient())
            {
                var result = await htppClient.PostAsync(oauthEndpoint, new FormUrlEncodedContent(new[]
                {
                    new KeyValuePair<string, string>("resource", ResourceUrl),
                    new KeyValuePair<string, string>("client_id", ClientId),
                    new KeyValuePair<string, string>("grant_type", "client_credentials"),
                    new KeyValuePair<string, string>("client_secret", ClientSecret),
                    new KeyValuePair<string, string>("scope", "openid")
                }));

                var content = await result.Content.ReadAsStringAsync();
                authenticationResult = JsonConvert.DeserializeObject<OAuthResult>(content);
            }*/

            AuthenticationContext authContext = new AuthenticationContext(AuthorityUrl);
            ClientCredential clientCredential = new ClientCredential(ClientId, ClientSecret);
            AuthenticationResult authenticationResult = await authContext.AcquireTokenAsync(ResourceUrl, clientCredential);

            var tokenCredentials = new TokenCredentials(authenticationResult.AccessToken, "Bearer");

            Client = new PowerBIClient(new Uri(ApiUrl), tokenCredentials);
        }
    }
}
