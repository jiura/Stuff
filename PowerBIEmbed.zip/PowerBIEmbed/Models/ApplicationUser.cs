﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace PowerBIEmbed.Models
{
    // Add profile data for application users by adding properties to the ApplicationUser class
    public class ApplicationUser : IdentityUser
    {
        public string UserCompany { get; set; }
        public byte[] UserPhoto { get; set; }
        public string Name { get; set; }
        public AccountViewModels.RegisterViewModel.UserRoles UserRole { get; set; }

        public virtual ICollection<MenuUser> MenuUsers { get; set; }
        public virtual ICollection<UserDominio> UsersDominios { get; set; }
    }
}
