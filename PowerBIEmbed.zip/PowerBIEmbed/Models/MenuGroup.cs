﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PowerBIEmbed.Models
{
    public class MenuGroup
    {
        public int ID { get; set; }
        [Display(Name = "Nome")]
        [Required]
        public string Name { get; set; }
        [Display(Name = "Ícone")]
        [Required]
        public byte[] Icon { get; set; }

        public virtual ICollection<Menu> Menus { get; set; }
    }
}
