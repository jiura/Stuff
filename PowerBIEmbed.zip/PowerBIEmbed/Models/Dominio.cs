﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PowerBIEmbed.Models
{
    public class Dominio
    {
        public int ID { get; set; }
        [Required]
        [Display(Name = "Nome")]
        public string Name { get; set; }
        [Required]
        public int CSAID { get; set; }

        public virtual ICollection<UserDominio> UsersDominios { get; set; }
    }


    public class UserDominio
    {
        [Display(Name = "Domínio")]
        public int DominioID { get; set; }
        public Dominio Dominio { get; set; }
        [Display(Name = "Usuário")]
        public string UserID { get; set; }
        public ApplicationUser User { get; set; }
    }
}
