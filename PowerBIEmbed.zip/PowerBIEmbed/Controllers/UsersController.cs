﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using PowerBIEmbed.Models;
using PowerBIEmbed.Models.AccountViewModels;
using PowerBIEmbed.Services;
using Microsoft.AspNetCore.Http;
using System.IO;
using PowerBIEmbed.Data;
using Microsoft.EntityFrameworkCore;

namespace PowerBIEmbed.Controllers
{
    [Authorize]
    [Route("[controller]/[action]")]
    public class UsersController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly IEmailSender _emailSender;
        private readonly ApplicationDbContext _context;

        public UsersController(
            UserManager<ApplicationUser> userManager,
            IEmailSender emailSender,
            ApplicationDbContext context)
        {
            
            _userManager = userManager;
           // _signInManager = signInManager;
            _emailSender = emailSender;
            //_logger = logger;
            _context = context;
        }

        [HttpGet]
        public IActionResult List()
        {
            return View(_userManager.Users.Where(u => u.UserRole == RegisterViewModel.UserRoles.Administrator).ToList());
        }

        [HttpGet]
        public IActionResult UsersTable(RegisterViewModel.UserRoles userRole)
        {
            return PartialView("UsersTable", _userManager.Users.Where(u => u.UserRole == userRole).ToList());
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(RegisterViewModel model, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;

            byte[] imageData = null;
            if (model.FileToUpload != null)
            {
                imageData = await IFormFileExtensions.GetFileArray(model.FileToUpload);
            }

            if (ModelState.IsValid)
            {
                var user = new ApplicationUser { Name = model.Name, UserName = model.Email, Email = model.Email, UserCompany = model.UserCompany, UserPhoto = imageData, UserRole = model.UserRole };
                var result = await _userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    user = await _userManager.FindByEmailAsync(model.Email);
                    result = await _userManager.AddToRoleAsync(user, model.UserRole.ToString());
                    if (!result.Succeeded)
                    {
                        await _userManager.DeleteAsync(user);
                        ModelState.AddModelError(string.Empty, "Erro ao adicionar role do usuário. Usuário removido.");
                        return View();
                    }
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Erro ao criar usuário.");
                    return View();
                }
            }
            else
                return View();

            return RedirectToAction(nameof(this.List), "Users");
        }

        [HttpGet]
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(ApplicationUser user, IFormFile userPhoto)
        {
            var userToUpdate = await _userManager.FindByIdAsync(user.Id);
            userToUpdate.Name = user.Name;
            userToUpdate.UserCompany = user.UserCompany;

            if (userPhoto != null)
            {
                MemoryStream filestream = new MemoryStream();
                await userPhoto.CopyToAsync(filestream);
                userToUpdate.UserPhoto = filestream.ToArray();
            }

            var result = await _userManager.UpdateAsync(userToUpdate);
            if (result.Succeeded)
            {
                return RedirectToAction(nameof(this.List), "Users");
            }

            ModelState.AddModelError(string.Empty, "Erro ao editar usuário.");
            return View(user);

        }

        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await _userManager.FindByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(string id)
        {
            var user = await _userManager.FindByIdAsync(id);
            var result = await _userManager.DeleteAsync(user);

            if (result.Succeeded)
                return RedirectToAction(nameof(this.List), "Users");

            ModelState.AddModelError(string.Empty, "Erro ao remover usuário.");
            return View();
        }

        #region Permissions

        [HttpGet]
        public async Task<IActionResult> Permissions(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await _context.Users.Include("UsersDominios.Dominio").Where(u => u.Id == id).SingleAsync();
            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        #endregion


        private IActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction(nameof(ReportsController.Geral), "Reports");
            }
        }

    }
}
