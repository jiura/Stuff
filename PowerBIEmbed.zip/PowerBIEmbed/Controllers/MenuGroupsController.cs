﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PowerBIEmbed.Data;
using PowerBIEmbed.Models;
using Microsoft.AspNetCore.Http;
using System.IO;

namespace PowerBIEmbed.Controllers
{
    public class MenuGroupsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public MenuGroupsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: MenuGroups
        public async Task<IActionResult> Index()
        {
            return View(await _context.Groups.ToListAsync());
        }

        // GET: MenuGroups/Create
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Name")] MenuGroup menuGroup, IFormFile iconImage)
        {
            if (iconImage != null)
            {
                MemoryStream filestream = new MemoryStream();
                await iconImage.CopyToAsync(filestream);
                menuGroup.Icon = filestream.ToArray();
            }

            if (menuGroup.Icon == null)
                ModelState.AddModelError("", "Favor escolher uma imagem de ícone.");
            
            if (!string.IsNullOrEmpty(menuGroup.Name) && menuGroup.Icon != null)
            {
                _context.Add(menuGroup);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(menuGroup);
        }
        public ActionResult MenuGroupIcon(int id)
        {
            var menuGroup = _context.Groups.Find(id);
            return File(menuGroup.Icon, "image/jpeg");
        }

        // GET: MenuGroups/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var menuGroup = await _context.Groups.FindAsync(id);
            if (menuGroup == null)
            {
                return NotFound();
            }
            return View(menuGroup);
        }

        // POST: MenuGroups/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Name")] MenuGroup menuGroup, IFormFile iconImage)
        {
            if (iconImage != null)
            {
                MemoryStream filestream = new MemoryStream();
                await iconImage.CopyToAsync(filestream);
                menuGroup.Icon = filestream.ToArray();
            }

            if (id != menuGroup.ID)
            {
                return NotFound();
            }

            if (!string.IsNullOrEmpty(menuGroup.Name))
            {
                try
                {
                    _context.Update(menuGroup);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MenuGroupExists(menuGroup.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(menuGroup);
        }

        // GET: MenuGroups/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var menuGroup = await _context.Groups
                .FirstOrDefaultAsync(m => m.ID == id);
            if (menuGroup == null)
            {
                return NotFound();
            }

            return View(menuGroup);
        }

        // POST: MenuGroups/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var menuGroup = await _context.Groups.FindAsync(id);
            _context.Groups.Remove(menuGroup);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MenuGroupExists(int id)
        {
            return _context.Groups.Any(e => e.ID == id);
        }
    }
}
