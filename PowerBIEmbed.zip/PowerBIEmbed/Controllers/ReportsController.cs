﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.PowerBI.Api.V2;
using Microsoft.PowerBI.Api.V2.Models;
using Microsoft.Extensions.Options;
using Microsoft.Rest;
using Newtonsoft.Json;
using PowerBIEmbed.Models;
using PowerBIEmbed.Data;

namespace PowerBIEmbed.Controllers
{
    public class ReportsController : Controller
    {
        private readonly PBIEmbeddedConfig _pBIEmbeddedConfig;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _context;

        public ReportsController(IOptions<PBIEmbeddedConfig> pBIEmbeddedConfig, UserManager<ApplicationUser> userManager, ApplicationDbContext context)
        {
            _pBIEmbeddedConfig = pBIEmbeddedConfig.Value;
            _userManager = userManager;
            _context = context;
        }

        public ActionResult Geral()
        {
            return View();
        }

        public async Task<ActionResult> GetReport(int menuID, string filterValue)
        {
            ViewData["MenuId"] = menuID;
            ViewData["FilterValue"] = filterValue;

            Menu menu = _context.Menus.Where(m => m.ID == menuID).First();
            var usuarioLogado = _userManager.GetUserId(HttpContext.User);

            PBIEmbeddedConfig pbi = _pBIEmbeddedConfig;
            await pbi.InitializeClient();
            
            var reports = await pbi.Client.Reports.GetReportsInGroupAsync(menu.WorkspaceID.ToString());
            Report report = reports.Value.FirstOrDefault(r => r.Id == menu.ReportID.ToString());
            var dataset = await pbi.Client.Datasets.GetDatasetByIdInGroupAsync(menu.WorkspaceID.ToString(), menu.DatasetID.ToString());
            /*GenerateTokenRequest generateTokenRequestParameters = new GenerateTokenRequest("View", null, identities: 
                new List<EffectiveIdentity> { new EffectiveIdentity(username: usuarioLogado, 
                                                                    roles: new List<string> { menu.RoleName }, 
                                                                    datasets: new List<string> { dataset.Id }) });*/

            GenerateTokenRequest generateTokenRequestParameters = new GenerateTokenRequest("View", null, identities:
                new List<EffectiveIdentity> { new EffectiveIdentity(username: "652",
                                                                    roles: new List<string> { menu.RoleName },
                                                                    datasets: new List<string> { dataset.Id }) });

            var tokenResponse = await pbi.Client.Reports.GenerateTokenInGroupAsync(menu.WorkspaceID.ToString(), report.Id, generateTokenRequestParameters);

            pbi.Client.Dispose();

            // Generate Embed Configuration.
            EmbedConfig retorno = new EmbedConfig();
            retorno.EmbedToken = tokenResponse;
            retorno.EmbedUrl = report.EmbedUrl;
            retorno.Id = report.Id;
            retorno.ReportPageName = menu.ReportPageName;
            retorno.ReportRatio = ((int)(Math.Ceiling((decimal)menu.ReportHeight * 100 / menu.ReportWidth))) + 1;
            retorno.IsEffectiveIdentityRequired = dataset.IsEffectiveIdentityRequired;
            retorno.IsEffectiveIdentityRolesRequired = dataset.IsEffectiveIdentityRolesRequired;

            return View(retorno);
        }

        [HttpPost]
        public ActionResult FilterReport(int menuID, string filterValue)
        {
            return RedirectToAction("GetReport", new { menuID = menuID, filterValue = filterValue });
        }
    }
}