﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PowerBIEmbed.Data;
using PowerBIEmbed.Models;
using Microsoft.Extensions.Options;
using Microsoft.PowerBI.Api.V2;

namespace PowerBIEmbed.Controllers
{
    public class MenusController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly PBIEmbeddedConfig _pbi;

        public MenusController(IOptions<PBIEmbeddedConfig> pBIEmbeddedConfig, ApplicationDbContext context)
        {
            _pbi = pBIEmbeddedConfig.Value;
            _context = context;
        }

        // GET: Menus
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.Menus.Include(m => m.Group);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: Menus/Create
        public async Task<IActionResult> Create()
        {
            await _pbi.InitializeClient();
            var getWorkspaces = await _pbi.Client.Groups.GetGroupsWithHttpMessagesAsync(/*"isOnDedicatedCapacity eq true"*/);
            var workspaces = getWorkspaces.Body.Value;
            var getReports = await _pbi.Client.Reports.GetReportsInGroupAsync(workspaces[0].Id);
            var reports = getReports.Value;
            _pbi.Client.Dispose();

            ViewData["WorkspaceID"] = new SelectList(workspaces.OrderBy(w => w.Name), "Id", "Name");
            ViewData["ReportID"] = new SelectList(reports.OrderBy(r => r.Name), "Id", "Name");
            ViewData["MenuGroupID"] = new SelectList(_context.Groups, "ID", "Name");
            return View();
        }

        public async Task<JsonResult> getReportsByWorkspace(string workspaceID)
        {
            await _pbi.InitializeClient();
            var getReports = await _pbi.Client.Reports.GetReportsInGroupAsync(workspaceID);
            var reports = getReports.Value;
            _pbi.Client.Dispose();

            return Json(new SelectList(reports, "Id", "Name"));
        }

        // POST: Menus/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Order,Name,WorkspaceID,ReportID,ReportPageName,MenuGroupID,ReportWidth,ReportHeight,RoleName")] Menu menu)
        {
            await _pbi.InitializeClient();
            var getWorkspaces = await _pbi.Client.Groups.GetGroupsWithHttpMessagesAsync(/*"isOnDedicatedCapacity eq true"*/);
            var workspaces = getWorkspaces.Body.Value;
            var getReports = await _pbi.Client.Reports.GetReportsInGroupAsync(menu.WorkspaceID.ToString());
            var reports = getReports.Value;
            var report = await _pbi.Client.Reports.GetReportAsync(menu.WorkspaceID.ToString(), menu.ReportID.ToString());
            _pbi.Client.Dispose();

            menu.DatasetID = new Guid(report.DatasetId);

            if (ModelState.IsValid)
            {
                _context.Add(menu);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            ViewData["WorkspaceID"] = new SelectList(workspaces.OrderBy(w => w.Name), "Id", "Name", menu.WorkspaceID.ToString());
            ViewData["ReportID"] = new SelectList(reports.OrderBy(r => r.Name), "Id", "Name", menu.ReportID.ToString());
            ViewData["MenuGroupID"] = new SelectList(_context.Groups, "ID", "Name", menu.MenuGroupID);
            return View(menu);
        }

        // GET: Menus/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var menu = await _context.Menus.FindAsync(id);
            if (menu == null)
            {
                return NotFound();
            }

            await _pbi.InitializeClient();
            var getWorkspaces = await _pbi.Client.Groups.GetGroupsWithHttpMessagesAsync("isOnDedicatedCapacity eq true");
            var workspaces = getWorkspaces.Body.Value;
            var getReports = await _pbi.Client.Reports.GetReportsInGroupAsync(menu.WorkspaceID.ToString());
            var reports = getReports.Value;
            _pbi.Client.Dispose();

            ViewData["WorkspaceID"] = new SelectList(workspaces.OrderBy(w => w.Name), "Id", "Name", menu.WorkspaceID.ToString());
            ViewData["ReportID"] = new SelectList(reports.OrderBy(r => r.Name), "Id", "Name", menu.ReportID.ToString());
            ViewData["MenuGroupID"] = new SelectList(_context.Groups, "ID", "Name", menu.MenuGroupID);
            return View(menu);
        }

        // POST: Menus/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Order,Name,DatasetID,ReportID,ReportPageName,MenuGroupID,ReportWidth,ReportHeight")] Menu menu)
        {
            if (id != menu.ID)
            {
                return NotFound();
            }

            await _pbi.InitializeClient();
            var getWorkspaces = await _pbi.Client.Groups.GetGroupsWithHttpMessagesAsync("isOnDedicatedCapacity eq true");
            var workspaces = getWorkspaces.Body.Value;
            var getReports = await _pbi.Client.Reports.GetReportsInGroupAsync(menu.WorkspaceID.ToString());
            var reports = getReports.Value;
            var report = await _pbi.Client.Reports.GetReportAsync(menu.WorkspaceID.ToString(), menu.ReportID.ToString());
            _pbi.Client.Dispose();

            menu.DatasetID = new Guid(report.DatasetId);

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(menu);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MenuExists(menu.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            ViewData["WorkspaceID"] = new SelectList(workspaces.OrderBy(w => w.Name), "Id", "Name", menu.WorkspaceID.ToString());
            ViewData["ReportID"] = new SelectList(reports.OrderBy(r => r.Name), "Id", "Name", menu.ReportID.ToString());
            ViewData["MenuGroupID"] = new SelectList(_context.Groups, "ID", "Name", menu.MenuGroupID);
            return View(menu);
        }

        // GET: Menus/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var menu = await _context.Menus
                .Include(m => m.Group)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (menu == null)
            {
                return NotFound();
            }

            return View(menu);
        }

        // POST: Menus/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var menu = await _context.Menus.FindAsync(id);
            _context.Menus.Remove(menu);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MenuExists(int id)
        {
            return _context.Menus.Any(e => e.ID == id);
        }
    }
}
