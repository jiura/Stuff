﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PowerBIEmbed.Data;
using PowerBIEmbed.Models;

namespace PowerBIEmbed.Controllers
{
    public class UserDominiosController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UserDominiosController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Create(string userID)
        {
            var userDominio = new UserDominio() { UserID = userID };

            ViewData["DominioID"] = new SelectList(_context.Dominios, "ID", "Name");
            ViewData["UserID"] = new SelectList(_context.Users, "Id", "Name", userDominio.UserID);

            return View(userDominio);
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("DominioID,UserID")] UserDominio userDominio)
        {
            if (ModelState.IsValid)
            {
                _context.Add(userDominio);
                await _context.SaveChangesAsync();
                return RedirectToAction("Permissions", "Users", new { id = userDominio.UserID });
            }
            ViewData["DominioID"] = new SelectList(_context.Dominios, "ID", "Name", userDominio.DominioID);
            ViewData["UserID"] = new SelectList(_context.Users, "Id", "Id", userDominio.UserID);
            return View(userDominio);
        }

        // POST: UserDominios/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int dominioID, string userID)
        {
            var userDominio = await _context.UserDominio.FindAsync(dominioID, userID);
            _context.UserDominio.Remove(userDominio);
            await _context.SaveChangesAsync();
            return RedirectToAction("Permissions", "Users", new { id = userDominio.UserID });
        }

        private bool UserDominioExists(int id)
        {
            return _context.UserDominio.Any(e => e.DominioID == id);
        }
    }
}
