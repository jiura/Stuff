﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PowerBIEmbed.Data;
using PowerBIEmbed.Models;

namespace PowerBIEmbed.Controllers
{
    public class DominiosController : Controller
    {
        private readonly ApplicationDbContext _context;

        public DominiosController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Dominios
        public async Task<IActionResult> Index()
        {
            return View(await _context.Dominios.ToListAsync());
        }

        // GET: Dominios/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Dominios/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,Name,CSAID")] Dominio dominio)
        {
            if (ModelState.IsValid)
            {
                _context.Add(dominio);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(dominio);
        }

        // GET: Dominios/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dominio = await _context.Dominios.FindAsync(id);
            if (dominio == null)
            {
                return NotFound();
            }
            return View(dominio);
        }

        // POST: Dominios/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,Name,CSAID")] Dominio dominio)
        {
            if (id != dominio.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(dominio);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!DominioExists(dominio.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(dominio);
        }

        // GET: Dominios/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var dominio = await _context.Dominios
                .FirstOrDefaultAsync(m => m.ID == id);
            if (dominio == null)
            {
                return NotFound();
            }

            return View(dominio);
        }

        // POST: Dominios/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var dominio = await _context.Dominios.FindAsync(id);
            _context.Dominios.Remove(dominio);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool DominioExists(int id)
        {
            return _context.Dominios.Any(e => e.ID == id);
        }
    }
}
