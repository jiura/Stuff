﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PowerBIEmbed.Data;
using PowerBIEmbed.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.EntityFrameworkCore;

namespace PowerBIEmbed.Controllers
{
    public class MenuViewComponent : ViewComponent
    {
        private readonly PBIEmbeddedConfig _pBIEmbeddedConfig;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ApplicationDbContext _context;
        
        public MenuViewComponent(IOptions<PBIEmbeddedConfig> pBIEmbeddedConfig, UserManager<ApplicationUser> userManager, ApplicationDbContext context)
        {
            _pBIEmbeddedConfig = pBIEmbeddedConfig.Value;
            _userManager = userManager;
            _context = context;
        }

        public async Task<IViewComponentResult> InvokeAsync()
        {
            MenuViewModel model = new MenuViewModel();
            //model.groups = await _context.Groups.Include(g => g.Menus).ToListAsync();

            var groups = await _context.Groups.Select(g => new
                                                        {
                                                            Groups = g,
                                                            Menus = g.Menus.OrderBy(m => m.Order)
                                                        })
                                                        .ToArrayAsync();
            
            foreach (var group in groups)
            {
                group.Groups.Menus = group.Menus.ToList();
            }

            model.groups = groups.Select(x => x.Groups).ToList();

            if (HttpContext.Request.QueryString.HasValue && ViewContext.RouteData.Values["controller"].ToString().ToLower().Equals("reports"))
            {
                int menuID = int.Parse(Request.Query["menuID"].ToString());
                Menu menu = _context.Menus.Where(m => m.ID == menuID).First();
                model.IDCurrentGroup = menu.MenuGroupID;
                model.IDCurrentMenu = menu.ID;
            }
            return View(model);
        }
    }

    public class MenuViewModel
    {
        public List<MenuGroup> groups;
        public int IDCurrentGroup;
        public int IDCurrentMenu;
    }
}