﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PowerBIEmbed.Models;
using Microsoft.AspNetCore.Identity;

namespace PowerBIEmbed.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<MenuGroup> Groups { get; set; }
        public DbSet<Menu> Menus { get; set; }

        public DbSet<Dominio> Dominios { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            #region Many to Many de Menu e Usuário

            builder.Entity<MenuUser>()
                .HasKey(mu => new { mu.MenuID, mu.UserID });

            builder.Entity<MenuUser>()
                .HasOne(bc => bc.Menu)
                .WithMany(b => b.MenuUsers)
                .HasForeignKey(bc => bc.MenuID);

            builder.Entity<MenuUser>()
                .HasOne(bc => bc.User)
                .WithMany(c => c.MenuUsers)
                .HasForeignKey(bc => bc.UserID);

            #endregion

            #region Many to Many de Dominio e Usuário

            builder.Entity<UserDominio>()
                .HasKey(ucsa => new { ucsa.DominioID, ucsa.UserID });

            builder.Entity<UserDominio>()
                .HasOne(ucsa => ucsa.Dominio)
                .WithMany(csa => csa.UsersDominios)
                .HasForeignKey(ucsa => ucsa.DominioID);

            builder.Entity<UserDominio>()
                .HasOne(ucsa => ucsa.User)
                .WithMany(u => u.UsersDominios)
                .HasForeignKey(ucsa => ucsa.UserID);

            #endregion

            base.OnModelCreating(builder);
        }

        public DbSet<PowerBIEmbed.Models.UserDominio> UserDominio { get; set; }
    }
}
