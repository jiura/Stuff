﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PowerBIEmbed.Data;
using PowerBIEmbed.Models;
using PowerBIEmbed.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Authorization;

namespace PowerBIEmbed
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));

            services.AddIdentity<ApplicationUser, IdentityRole>()
                .AddEntityFrameworkStores<ApplicationDbContext>()
                .AddDefaultTokenProviders();

            // Add application services.
            services.AddTransient<IEmailSender, EmailSender>();

            services.Configure<PBIEmbeddedConfig>(Configuration.GetSection("PBIEmbeddedConfig"));

            services.ConfigureApplicationCookie(options => options.LoginPath = "/Account/Login");

            services.AddMvc();

            services.AddMvc(o =>
            {
                var policy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .Build();
                o.Filters.Add(new AuthorizeFilter(policy));
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseDatabaseErrorPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
            }

            app.UseStaticFiles();

            app.UseAuthentication();

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "DynamicReportsRoute",
                    template: "Reports/{*reportName}",
                    defaults: new { controller = "ReportsController", action = "GetReport" }
                    );

                routes.MapRoute(
                    name: "default",
                    template: "{controller=Reports}/{action=Geral}/{id?}");
            });

            ConfigureIdentity(app.ApplicationServices).Wait();
        }

        public static async Task ConfigureIdentity(IServiceProvider services)
        {
            string[] applicationRoles = new string[] { "Administrator", "Comum" };

            IServiceScopeFactory scopeFactory = services.GetRequiredService<IServiceScopeFactory>();

            using (IServiceScope scope = scopeFactory.CreateScope())
            {
                RoleManager<IdentityRole> roles = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();

                foreach (var appRole in applicationRoles)
                {
                    if (!await roles.RoleExistsAsync(appRole))
                    {
                        await roles.CreateAsync(new IdentityRole(appRole));
                    }
                }

                UserManager<ApplicationUser> userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();

                var admin = await userManager.FindByEmailAsync("admin@admin.com");
                if (admin == null)
                {
                    admin = new ApplicationUser();
                    admin.UserName = "admin@admin.com";
                    admin.Email = "admin@admin.com";
                    await userManager.CreateAsync(admin, "Admin@123");
                }
                admin = await userManager.FindByEmailAsync("admin@admin.com");
                var adminRoles = await userManager.GetRolesAsync(admin);
                if (!adminRoles.Contains("Administrator"))
                    await userManager.AddToRoleAsync(admin, "Administrator");
            }
        }
    }
}
